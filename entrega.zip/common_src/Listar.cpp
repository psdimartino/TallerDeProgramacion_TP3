#include "../common_src/Listar.h"

void Listar::ejecutar(MapaDePartidas &partidas,
                            std::string &nombrePartida, char &jugador) {
    result << partidas;
}
